Para usar los programas realizados hacer clic en el ejecutable (".exe")
en caso de necesitarse pasar a otra ubicación llevar el .cpp y los .txt dentro
de la carpeta para el correcto uso del programa
