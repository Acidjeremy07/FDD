//Cazares Cruz Jeremy Sajid

#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	int a,i,j,k,n,d1[i];
	d1[i]=1;
	d1[i]=5;
	d1[i]=10;
	d1[i]=25;
	d1[i]=100;
	d1[i]=200;
	d1[i]=500;
	for(i=0;i<7;i++)
	{
		a=d1[i];
		cout<<"denominacion 1"<<a<<endl;
	}
}
